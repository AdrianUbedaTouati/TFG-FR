Artefactos generados:
- confusion_matrix_raw.png / confusion_matrix_raw.csv
- confusion_matrix_row_normalized.png / confusion_matrix_row_normalized.csv
- classification_report.json / classification_report_per_class.csv
- f1_per_class.png
- class_count_*.png / class_fraction_*.png (si hay label_distribution.json)
- top_confusions.csv
